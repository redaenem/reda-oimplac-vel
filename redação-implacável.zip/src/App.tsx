/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Wand2, 
  PenTool, 
  Library, 
  BarChart3, 
  ChevronRight, 
  Star, 
  CheckCircle2, 
  AlertCircle,
  Loader2,
  Menu,
  X,
  ArrowRight,
  Trophy,
  History,
  LogIn,
  UserPlus,
  LogOut,
  User as UserIcon,
  Lock
} from 'lucide-react';
import { AppView, EssayStructure, EssayAnalysis, UserProgress, User } from './types';
import { generateStructure, analyzeEssay } from './lib/gemini';
import { cn } from './lib/utils';
import ReactMarkdown from 'react-markdown';

// --- Components ---

const AuthView = ({ onAuthSuccess }: { onAuthSuccess: (user: User) => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const users = JSON.parse(localStorage.getItem('redacao_implacavel_users') || '[]');

    if (isLogin) {
      const user = users.find((u: any) => u.email === email && u.password === password);
      if (user) {
        onAuthSuccess({ id: user.id, email: user.email, name: user.name });
      } else {
        setError('Email ou senha incorretos.');
      }
    } else {
      if (users.some((u: any) => u.email === email)) {
        setError('Este email já está cadastrado.');
        return;
      }
      const newUser = { id: Date.now().toString(), email, password, name };
      users.push(newUser);
      localStorage.setItem('redacao_implacavel_users', JSON.stringify(users));
      onAuthSuccess({ id: newUser.id, email: newUser.email, name: newUser.name });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gray-50">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-brand-black rounded-2xl flex items-center justify-center text-white font-display font-bold text-3xl shadow-xl mx-auto mb-6">R</div>
          <h1 className="text-3xl font-display font-bold tracking-tight">Redação Implacável</h1>
          <p className="text-gray-500">
            {isLogin ? 'Entre na sua conta para continuar' : 'Crie sua conta e comece sua jornada'}
          </p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                  <UserIcon size={16} /> Nome Completo
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            )}
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <LogIn size={16} /> Email
              </label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <Lock size={16} /> Senha
              </label>
              <input
                type="password"
                required
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm flex items-center gap-2">
                <AlertCircle size={16} /> {error}
              </div>
            )}

            <button type="submit" className="btn-primary w-full py-4 text-lg">
              {isLogin ? 'Entrar' : 'Criar Conta'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t text-center">
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm font-semibold text-brand-red hover:underline"
            >
              {isLogin ? 'Não tem uma conta? Cadastre-se' : 'Já tem uma conta? Entre aqui'}
            </button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

const SidebarItem = ({ 
  icon: Icon, 
  label, 
  active, 
  onClick 
}: { 
  icon: any, 
  label: string, 
  active: boolean, 
  onClick: () => void 
}) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-200",
      active 
        ? "bg-brand-black text-white shadow-lg" 
        : "text-gray-500 hover:bg-gray-100 hover:text-brand-black"
    )}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </button>
);

const Card = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("glass-card p-6", className)}>
    {children}
  </div>
);

// --- Views ---

const DashboardView = ({ setView, progress }: { setView: (v: AppView) => void, progress: UserProgress }) => (
  <div className="space-y-8">
    <header>
      <h1 className="text-4xl mb-2">Bem-vindo ao Redação Implacável</h1>
      <p className="text-gray-500 text-lg">Aqui você vai aprender e aplicar a mesma estrutura usada nas redações nota 1000 do ENEM.</p>
    </header>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="bg-brand-black text-white border-none">
        <div className="flex justify-between items-start mb-4">
          <Trophy className="text-brand-gold" size={32} />
          <span className="text-xs font-bold uppercase tracking-wider opacity-60">Progresso Atual</span>
        </div>
        <div className="space-y-1">
          <h3 className="text-3xl font-bold">{progress.essaysWritten}</h3>
          <p className="text-gray-400">Redações escritas</p>
        </div>
      </Card>
      
      <Card>
        <div className="flex justify-between items-start mb-4">
          <Star className="text-brand-red" size={32} />
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Média de Notas</span>
        </div>
        <div className="space-y-1">
          <h3 className="text-3xl font-bold">{progress.averageScore.toFixed(0)}</h3>
          <p className="text-gray-500">Pontos no simulador</p>
        </div>
      </Card>

      <Card className="flex flex-col justify-center items-center text-center border-dashed border-2 border-gray-300 bg-gray-50/50">
        <button 
          onClick={() => setView('trainer')}
          className="group flex flex-col items-center gap-2"
        >
          <div className="w-12 h-12 rounded-full bg-brand-black text-white flex items-center justify-center group-hover:bg-brand-red transition-colors">
            <PenTool size={24} />
          </div>
          <span className="font-bold">Nova Redação</span>
        </button>
      </Card>
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-4">
        <h2 className="text-2xl">Ações Rápidas</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button 
            onClick={() => setView('generator')}
            className="p-6 rounded-2xl border-2 border-gray-100 hover:border-brand-black transition-all text-left group"
          >
            <Wand2 className="mb-4 text-brand-red group-hover:scale-110 transition-transform" size={28} />
            <h4 className="font-bold mb-1">Gerador de Estrutura</h4>
            <p className="text-sm text-gray-500">Crie um esqueleto para qualquer tema em segundos.</p>
          </button>
          <button 
            onClick={() => setView('structure-module')}
            className="p-6 rounded-2xl border-2 border-gray-100 hover:border-brand-black transition-all text-left group"
          >
            <BookOpen className="mb-4 text-brand-gold group-hover:scale-110 transition-transform" size={28} />
            <h4 className="font-bold mb-1">Aprender Estrutura</h4>
            <p className="text-sm text-gray-500">Domine os parágrafos nota 1000.</p>
          </button>
        </div>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl">Histórico Recente</h2>
          <History size={20} className="text-gray-400" />
        </div>
        <div className="space-y-4">
          {progress.scoreHistory.length > 0 ? (
            progress.scoreHistory.slice(-3).reverse().map((item, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-gray-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                    <CheckCircle2 size={18} className="text-green-500" />
                  </div>
                  <div>
                    <p className="font-semibold">Simulação #{progress.scoreHistory.length - i}</p>
                    <p className="text-xs text-gray-400">{item.date}</p>
                  </div>
                </div>
                <span className="font-display font-bold text-lg">{item.score}</span>
              </div>
            ))
          ) : (
            <p className="text-gray-400 text-center py-8 italic">Nenhuma redação realizada ainda.</p>
          )}
        </div>
      </Card>
    </div>
  </div>
);

const StructureModuleView = () => (
  <div className="max-w-4xl mx-auto space-y-12">
    <header className="text-center space-y-4">
      <h1 className="text-5xl">A Estrutura Nota 1000</h1>
      <p className="text-xl text-gray-500">O segredo não é o que você escreve, mas como você organiza.</p>
    </header>

    <div className="space-y-8">
      {[
        {
          title: "Introdução",
          points: ["Contextualização do tema (Repertório)", "Apresentação da tese (Problematização)", "Encaminhamento argumentativo"],
          color: "border-l-brand-red",
          example: "Historicamente, a sociedade brasileira... Nesse contexto, é imperativo analisar como a [Causa 1] e a [Causa 2] perpetuam esse cenário."
        },
        {
          title: "Desenvolvimento 1",
          points: ["Tópico frasal (Argumento 1)", "Repertório sociocultural", "Análise crítica / Desfecho"],
          color: "border-l-brand-black",
          example: "Em primeira análise, cabe pontuar que a [Causa 1] é um entrave. Segundo o filósofo [Nome]..."
        },
        {
          title: "Desenvolvimento 2",
          points: ["Tópico frasal (Argumento 2)", "Explicação + Exemplo prático", "Consequência social"],
          color: "border-l-brand-black",
          example: "Ademais, a [Causa 2] intensifica o problema. Isso ocorre porque..."
        },
        {
          title: "Conclusão",
          points: ["Agente (Quem faz?)", "Ação (O que faz?)", "Meio/Modo (Como faz?)", "Efeito/Finalidade (Para quê?)", "Detalhamento"],
          color: "border-l-brand-gold",
          example: "Portanto, medidas são necessárias. Cabe ao [Agente], por meio de [Meio], realizar [Ação], com o fito de [Finalidade]."
        }
      ].map((step, i) => (
        <Card key={i} className={cn("border-l-8", step.color)}>
          <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1">
              <h3 className="text-2xl mb-4">{step.title}</h3>
              <ul className="space-y-2">
                {step.points.map((p, pi) => (
                  <li key={pi} className="flex items-center gap-2 text-gray-600">
                    <CheckCircle2 size={16} className="text-brand-red" />
                    {p}
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex-1 bg-gray-50 p-4 rounded-xl border border-gray-100">
              <span className="text-xs font-bold text-gray-400 uppercase mb-2 block">Exemplo de Estrutura</span>
              <p className="text-sm italic text-gray-600 leading-relaxed">"{step.example}"</p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

const GeneratorView = () => {
  const [theme, setTheme] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EssayStructure | null>(null);

  const handleGenerate = async () => {
    if (!theme) return;
    setLoading(true);
    try {
      const data = await generateStructure(theme);
      setResult(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-4xl mb-2">Gerador de Estrutura</h1>
        <p className="text-gray-500">Insira o tema e receba um esqueleto completo para sua redação.</p>
      </header>

      <Card className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            placeholder="Ex: A persistência da violência contra a mulher no Brasil"
            className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
          />
          <button 
            onClick={handleGenerate}
            disabled={loading || !theme}
            className="btn-primary flex items-center justify-center gap-2 min-w-[160px]"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Wand2 size={20} />}
            Gerar
          </button>
        </div>
      </Card>

      <AnimatePresence mode="wait">
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="space-y-4">
                <h3 className="text-xl flex items-center gap-2">
                  <BookOpen className="text-brand-red" size={20} />
                  Introdução e Tese
                </h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <span className="font-bold text-gray-400 uppercase text-[10px]">Sugestão de Intro</span>
                    <p className="text-gray-700">{result.introduction}</p>
                  </div>
                  <div>
                    <span className="font-bold text-gray-400 uppercase text-[10px]">Tese Sugerida</span>
                    <p className="text-gray-700 font-medium">{result.thesis}</p>
                  </div>
                </div>
              </Card>

              <Card className="space-y-4">
                <h3 className="text-xl flex items-center gap-2">
                  <BarChart3 className="text-brand-black" size={20} />
                  Argumentos
                </h3>
                <div className="space-y-4 text-sm">
                  <div className="p-3 bg-gray-50 rounded-lg border-l-4 border-brand-black">
                    <span className="font-bold text-gray-400 uppercase text-[10px]">Argumento 1</span>
                    <p className="text-gray-700">{result.argument1}</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg border-l-4 border-brand-black">
                    <span className="font-bold text-gray-400 uppercase text-[10px]">Argumento 2</span>
                    <p className="text-gray-700">{result.argument2}</p>
                  </div>
                </div>
              </Card>
            </div>

            <Card className="space-y-4">
              <h3 className="text-xl flex items-center gap-2">
                <Library className="text-brand-gold" size={20} />
                Repertório Sociocultural
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {result.repertoire.map((item, i) => (
                  <div key={i} className="flex items-start gap-2 p-3 bg-brand-gold/5 rounded-xl border border-brand-gold/10">
                    <CheckCircle2 className="text-brand-gold mt-1 shrink-0" size={16} />
                    <span className="text-sm text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="space-y-4">
              <h3 className="text-xl flex items-center gap-2">
                <CheckCircle2 className="text-green-600" size={20} />
                Proposta de Intervenção
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "Agente", value: result.conclusion.agent },
                  { label: "Ação", value: result.conclusion.action },
                  { label: "Meio", value: result.conclusion.means },
                  { label: "Finalidade", value: result.conclusion.purpose },
                ].map((item, i) => (
                  <div key={i} className="p-3 bg-gray-50 rounded-xl">
                    <span className="font-bold text-gray-400 uppercase text-[10px]">{item.label}</span>
                    <p className="text-sm text-gray-700 font-medium">{item.value}</p>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const TrainerView = ({ onComplete }: { onComplete: (score: number) => void }) => {
  const [theme, setTheme] = useState('');
  const [text, setText] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<EssayAnalysis | null>(null);

  const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
  const paragraphCount = text.split('\n').filter(p => p.trim().length > 0).length;

  const handleAnalyze = async () => {
    if (!theme || !text) return;
    setAnalyzing(true);
    try {
      const result = await analyzeEssay(theme, text);
      setAnalysis(result);
      onComplete(result.score);
    } catch (error) {
      console.error(error);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl mb-2">Treinador de Redação</h1>
          <p className="text-gray-500">Escreva sua redação e receba feedback instantâneo da IA.</p>
        </div>
        <div className="flex gap-4">
          <div className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium">
            {wordCount} palavras
          </div>
          <div className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium">
            {paragraphCount}/4 parágrafos
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="space-y-4">
            <input
              type="text"
              placeholder="Tema da redação..."
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all font-bold text-lg"
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
            />
            <textarea
              placeholder="Comece a escrever sua redação aqui..."
              className="w-full h-[500px] px-4 py-4 rounded-xl border-2 border-gray-100 focus:border-brand-black outline-none transition-all resize-none leading-relaxed font-serif text-lg"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <div className="flex justify-end">
              <button
                onClick={handleAnalyze}
                disabled={analyzing || !text || !theme}
                className="btn-primary flex items-center gap-2"
              >
                {analyzing ? <Loader2 className="animate-spin" size={20} /> : <BarChart3 size={20} />}
                Analisar Redação
              </button>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {analysis ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <Card className="bg-brand-black text-white border-none text-center py-8">
                  <span className="text-brand-gold font-bold uppercase tracking-widest text-xs mb-2 block">Nota Estimada</span>
                  <h2 className="text-6xl font-display font-bold text-brand-gold">{analysis.score}</h2>
                  <p className="text-gray-400 mt-2">Baseado nos critérios do ENEM</p>
                </Card>

                <Card className="space-y-4">
                  <h3 className="font-bold flex items-center gap-2">
                    <BarChart3 size={18} className="text-brand-red" />
                    Competências
                  </h3>
                  <div className="space-y-3">
                    {[
                      { label: "C1: Norma Culta", val: analysis.competencies.c1 },
                      { label: "C2: Tema e Estrutura", val: analysis.competencies.c2 },
                      { label: "C3: Argumentação", val: analysis.competencies.c3 },
                      { label: "C4: Coesão", val: analysis.competencies.c4 },
                      { label: "C5: Intervenção", val: analysis.competencies.c5 },
                    ].map((c, i) => (
                      <div key={i} className="space-y-1">
                        <div className="flex justify-between text-xs font-bold">
                          <span className="text-gray-500">{c.label}</span>
                          <span>{c.val}/200</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${(c.val / 200) * 100}%` }}
                            className="h-full bg-brand-black"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card className="space-y-4">
                  <h3 className="font-bold flex items-center gap-2">
                    <CheckCircle2 size={18} className="text-green-500" />
                    Feedback Geral
                  </h3>
                  <div className="markdown-body">
                    <ReactMarkdown>{analysis.feedback}</ReactMarkdown>
                  </div>
                </Card>

                <Card className="space-y-4">
                  <h3 className="font-bold flex items-center gap-2">
                    <AlertCircle size={18} className="text-brand-gold" />
                    Sugestões de Melhoria
                  </h3>
                  <ul className="space-y-2">
                    {analysis.suggestions.map((s, i) => (
                      <li key={i} className="text-sm text-gray-600 flex gap-2">
                        <ArrowRight size={14} className="mt-1 shrink-0 text-brand-red" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </Card>
              </motion.div>
            ) : (
              <Card className="text-center py-12 space-y-4 bg-gray-50 border-dashed border-2">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <PenTool className="text-gray-300" size={32} />
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-gray-400">Aguardando Redação</h3>
                  <p className="text-sm text-gray-400 px-4">Escreva seu texto ao lado e clique em analisar para ver seu desempenho.</p>
                </div>
              </Card>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const LibraryView = () => {
  const models = [
    {
      theme: "Democratização do acesso ao cinema no Brasil",
      intro: "Na obra 'Utopia', de Thomas More, é retratada uma sociedade perfeita... Entretanto, a realidade brasileira distancia-se desse ideal...",
      args: ["A negligência estatal", "A elitização do consumo cultural"],
      conclusion: "O Ministério da Cultura deve, por meio de subsídios..."
    },
    {
      theme: "O estigma associado às doenças mentais",
      intro: "No filme 'Coringa', o protagonista sofre com a falta de empatia... Fora das telas, o cenário é análogo...",
      args: ["A desinformação midiática", "A insuficiência de políticas públicas"],
      conclusion: "O Ministério da Educação, em parceria com a Saúde..."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-4xl mb-2">Biblioteca de Modelos</h1>
        <p className="text-gray-500">Exemplos estruturados para você se inspirar e copiar a lógica.</p>
      </header>

      <div className="space-y-6">
        {models.map((m, i) => (
          <Card key={i} className="space-y-6">
            <div className="flex items-center gap-3 border-b pb-4">
              <div className="w-10 h-10 rounded-full bg-brand-black text-white flex items-center justify-center font-bold">
                {i + 1}
              </div>
              <h3 className="text-xl font-bold">{m.theme}</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <span className="text-xs font-bold text-brand-red uppercase">Introdução Modelo</span>
                <p className="text-sm text-gray-600 italic leading-relaxed">"{m.intro}"</p>
              </div>
              <div className="space-y-2">
                <span className="text-xs font-bold text-brand-black uppercase">Argumentos</span>
                <ul className="space-y-2">
                  {m.args.map((a, ai) => (
                    <li key={ai} className="text-sm text-gray-600 flex gap-2">
                      <CheckCircle2 size={14} className="mt-1 text-green-500" />
                      {a}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-2">
                <span className="text-xs font-bold text-brand-gold uppercase">Conclusão</span>
                <p className="text-sm text-gray-600 leading-relaxed">{m.conclusion}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

const ProgressView = ({ progress }: { progress: UserProgress }) => (
  <div className="max-w-4xl mx-auto space-y-8">
    <header>
      <h1 className="text-4xl mb-2">Sua Evolução</h1>
      <p className="text-gray-500">Acompanhe seu crescimento rumo à nota 1000.</p>
    </header>

    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
      <Card className="text-center py-10">
        <h3 className="text-gray-400 uppercase text-xs font-bold mb-2">Total de Redações</h3>
        <p className="text-6xl font-display font-bold">{progress.essaysWritten}</p>
      </Card>
      <Card className="text-center py-10">
        <h3 className="text-gray-400 uppercase text-xs font-bold mb-2">Média Geral</h3>
        <p className="text-6xl font-display font-bold text-brand-red">{progress.averageScore.toFixed(0)}</p>
      </Card>
    </div>

    <Card>
      <h3 className="text-xl mb-6 flex items-center gap-2">
        <BarChart3 className="text-brand-gold" />
        Gráfico de Desempenho
      </h3>
      <div className="h-64 flex items-end gap-2 px-4">
        {progress.scoreHistory.length > 0 ? (
          progress.scoreHistory.map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
              <div className="w-full bg-gray-100 rounded-t-lg relative overflow-hidden" style={{ height: `${(h.score / 1000) * 100}%` }}>
                <motion.div 
                  initial={{ height: 0 }}
                  animate={{ height: '100%' }}
                  className="w-full bg-brand-black group-hover:bg-brand-red transition-colors"
                />
                <div className="absolute top-2 left-0 right-0 text-center text-[10px] font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  {h.score}
                </div>
              </div>
              <span className="text-[10px] text-gray-400 font-bold uppercase">{h.date.split('/')[0]}/{h.date.split('/')[1]}</span>
            </div>
          ))
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400 italic">
            Ainda não há dados suficientes para gerar o gráfico.
          </div>
        )}
      </div>
    </Card>

    <div className="text-center py-12 space-y-4">
      <Trophy className="mx-auto text-brand-gold" size={48} />
      <h2 className="text-2xl">Continue Implacável!</h2>
      <p className="text-gray-500 max-w-md mx-auto">
        "Continue aplicando a estrutura das redações nota 1000 e aumente sua pontuação no ENEM."
      </p>
    </div>
  </div>
);

// --- Main App ---

export default function App() {
  const [view, setView] = useState<AppView>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [progress, setProgress] = useState<UserProgress>({
    essaysWritten: 0,
    averageScore: 0,
    scoreHistory: []
  });

  // Load user and progress from localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem('redacao_implacavel_current_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      
      const savedProgress = localStorage.getItem(`redacao_implacavel_progress_${parsedUser.id}`);
      if (savedProgress) {
        setProgress(JSON.parse(savedProgress));
      }
    }
  }, []);

  const handleAuthSuccess = (newUser: User) => {
    setUser(newUser);
    localStorage.setItem('redacao_implacavel_current_user', JSON.stringify(newUser));
    
    const savedProgress = localStorage.getItem(`redacao_implacavel_progress_${newUser.id}`);
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress));
    } else {
      const initialProgress = { essaysWritten: 0, averageScore: 0, scoreHistory: [] };
      setProgress(initialProgress);
      localStorage.setItem(`redacao_implacavel_progress_${newUser.id}`, JSON.stringify(initialProgress));
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('redacao_implacavel_current_user');
    setView('dashboard');
  };

  const handleEssayComplete = (score: number) => {
    if (!user) return;
    const newHistory = [...progress.scoreHistory, { 
      date: new Date().toLocaleDateString('pt-BR'), 
      score 
    }];
    const newProgress = {
      essaysWritten: progress.essaysWritten + 1,
      averageScore: newHistory.reduce((acc, curr) => acc + curr.score, 0) / newHistory.length,
      scoreHistory: newHistory
    };
    setProgress(newProgress);
    localStorage.setItem(`redacao_implacavel_progress_${user.id}`, JSON.stringify(newProgress));
  };

  if (!user) {
    return <AuthView onAuthSuccess={handleAuthSuccess} />;
  }

  const renderView = () => {
    switch (view) {
      case 'dashboard': return <DashboardView setView={setView} progress={progress} />;
      case 'structure-module': return <StructureModuleView />;
      case 'generator': return <GeneratorView />;
      case 'trainer': return <TrainerView onComplete={handleEssayComplete} />;
      case 'library': return <LibraryView />;
      case 'progress': return <ProgressView progress={progress} />;
      default: return <DashboardView setView={setView} progress={progress} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b p-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-black rounded-lg flex items-center justify-center text-white font-display font-bold">R</div>
          <span className="font-display font-bold tracking-tight">Redação Implacável</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-0 z-40 bg-white border-r p-6 transition-transform md:relative md:translate-x-0 md:w-72 md:flex md:flex-col",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="hidden md:flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-brand-black rounded-xl flex items-center justify-center text-white font-display font-bold text-xl shadow-lg">R</div>
          <span className="font-display font-bold text-xl tracking-tight">Redação Implacável</span>
        </div>

        <div className="mb-8 px-4 py-3 bg-gray-50 rounded-xl border border-gray-100">
          <p className="text-xs font-bold text-gray-400 uppercase mb-1">Usuário</p>
          <p className="font-semibold truncate">{user.name}</p>
        </div>

        <nav className="space-y-2 flex-1">
          <SidebarItem 
            icon={LayoutDashboard} 
            label="Dashboard" 
            active={view === 'dashboard'} 
            onClick={() => { setView('dashboard'); setIsSidebarOpen(false); }} 
          />
          <SidebarItem 
            icon={BookOpen} 
            label="Estrutura Nota 1000" 
            active={view === 'structure-module'} 
            onClick={() => { setView('structure-module'); setIsSidebarOpen(false); }} 
          />
          <SidebarItem 
            icon={Wand2} 
            label="Gerador de Estrutura" 
            active={view === 'generator'} 
            onClick={() => { setView('generator'); setIsSidebarOpen(false); }} 
          />
          <SidebarItem 
            icon={PenTool} 
            label="Treinador" 
            active={view === 'trainer'} 
            onClick={() => { setView('trainer'); setIsSidebarOpen(false); }} 
          />
          <SidebarItem 
            icon={Library} 
            label="Biblioteca" 
            active={view === 'library'} 
            onClick={() => { setView('library'); setIsSidebarOpen(false); }} 
          />
          <SidebarItem 
            icon={BarChart3} 
            label="Meu Progresso" 
            active={view === 'progress'} 
            onClick={() => { setView('progress'); setIsSidebarOpen(false); }} 
          />
        </nav>

        <div className="mt-auto pt-6 space-y-4">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-gray-500 hover:bg-red-50 hover:text-red-600 transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium">Sair da Conta</span>
          </button>
          
          <Card className="bg-brand-red/5 border-brand-red/10 p-4">
            <p className="text-xs font-bold text-brand-red uppercase mb-1">Dica do Dia</p>
            <p className="text-xs text-gray-600 leading-relaxed">
              Use conectores como "Em primeira análise" e "Ademais" para garantir a nota máxima na Competência 4.
            </p>
          </Card>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
