export interface EssayStructure {
  introduction: string;
  thesis: string;
  argument1: string;
  argument2: string;
  repertoire: string[];
  conclusion: {
    agent: string;
    action: string;
    means: string;
    purpose: string;
  };
}

export interface EssayAnalysis {
  score: number;
  competencies: {
    c1: number; // Norma culta
    c2: number; // Compreensão do tema
    c3: number; // Organização dos argumentos
    c4: number; // Coesão
    c5: number; // Proposta de intervenção
  };
  feedback: string;
  suggestions: string[];
}

export interface UserProgress {
  essaysWritten: number;
  averageScore: number;
  scoreHistory: { date: string; score: number }[];
}

export interface User {
  id: string;
  email: string;
  password?: string; // Only for local storage mock
  name: string;
}

export type AppView = 'dashboard' | 'structure-module' | 'generator' | 'trainer' | 'library' | 'progress' | 'auth';
