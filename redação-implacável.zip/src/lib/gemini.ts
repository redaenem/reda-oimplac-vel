import { GoogleGenAI, Type } from "@google/genai";
import { EssayStructure, EssayAnalysis } from "./types";

const apiKey = process.env.GEMINI_API_KEY || "";
const genAI = new GoogleGenAI({ apiKey });

export async function generateStructure(theme: string): Promise<EssayStructure> {
  const model = "gemini-3.1-pro-preview";
  const response = await genAI.models.generateContent({
    model,
    contents: `Como um especialista em redação do ENEM, gere uma estrutura nota 1000 para o tema: "${theme}". 
    Retorne um JSON com os campos: introduction, thesis, argument1, argument2, repertoire (array de strings), e conclusion (objeto com agent, action, means, purpose).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          introduction: { type: Type.STRING },
          thesis: { type: Type.STRING },
          argument1: { type: Type.STRING },
          argument2: { type: Type.STRING },
          repertoire: { type: Type.ARRAY, items: { type: Type.STRING } },
          conclusion: {
            type: Type.OBJECT,
            properties: {
              agent: { type: Type.STRING },
              action: { type: Type.STRING },
              means: { type: Type.STRING },
              purpose: { type: Type.STRING },
            },
            required: ["agent", "action", "means", "purpose"]
          }
        },
        required: ["introduction", "thesis", "argument1", "argument2", "repertoire", "conclusion"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}

export async function analyzeEssay(theme: string, text: string): Promise<EssayAnalysis> {
  const model = "gemini-3.1-pro-preview";
  const response = await genAI.models.generateContent({
    model,
    contents: `Analise a seguinte redação para o tema "${theme}" seguindo rigorosamente os critérios do ENEM (5 competências de 0 a 200 pontos cada).
    
    Texto da redação:
    ${text}
    
    Retorne um JSON com:
    - score (total de 0 a 1000)
    - competencies (objeto com c1, c2, c3, c4, c5, cada um de 0 a 200)
    - feedback (texto explicativo geral)
    - suggestions (array de strings com melhorias práticas)`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          competencies: {
            type: Type.OBJECT,
            properties: {
              c1: { type: Type.NUMBER },
              c2: { type: Type.NUMBER },
              c3: { type: Type.NUMBER },
              c4: { type: Type.NUMBER },
              c5: { type: Type.NUMBER },
            },
            required: ["c1", "c2", "c3", "c4", "c5"]
          },
          feedback: { type: Type.STRING },
          suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["score", "competencies", "feedback", "suggestions"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
